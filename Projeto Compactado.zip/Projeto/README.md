# FraudNet AI — Streamlit com CSV, APIs e Modelo de Inferência

Plataforma analítica para detecção de fraudes, análise de redes e integração com APIs financeiras.

## Funcionalidades

- Análise de bases `.csv` no layout FraudNet.
- Adaptação de bases PaySim.
- Treinamento supervisionado com `is_fraud`.
- Uso de modelo salvo `.joblib` para inferência.
- Consulta dinâmica à API pública CFPB.
- Conector genérico para APIs JSON configuradas pelo usuário.
- Consulta a séries públicas do Banco Central do Brasil.
- Exportação dos resultados em CSV.

## Como executar localmente

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

No Windows, execute:

```text
run_app.bat
```

## Estrutura

```text
app.py
pages/
  01_Analisar_CSV.py
  02_Treinar_Modelo.py
  03_API_CFPB.py
  04_API_Externa.py
  05_Contexto_BCB.py
core/
  fraud_engine.py
  schema.py
connectors/
  cfpb_client.py
  generic_api_client.py
  bcb_client.py
utils/
  ui_helpers.py
```

## Layout FraudNet esperado

```text
transaction_id
user_id
device_id
card_id
ip_id
amount
hour
country
channel
is_fraud
```

A coluna `is_fraud` é obrigatória somente para treino.

## API Externa

Na página **API Externa**, o usuário configura:

- URL pública da API;
- método GET ou POST;
- parâmetros JSON;
- headers JSON;
- token opcional;
- caminho dos dados no JSON;
- mapeamento das colunas para o layout FraudNet.

Tokens informados pelo usuário são usados somente durante a sessão atual e não são salvos em arquivo.

## Segurança

O conector genérico bloqueia:

- localhost;
- IPs privados;
- esquemas que não sejam HTTP/HTTPS.

## Observação

Este projeto é demonstrativo e usa dados sintéticos ou públicos. Não utilize o modelo diretamente em produção sem validação estatística, governança, segurança e monitoramento.
