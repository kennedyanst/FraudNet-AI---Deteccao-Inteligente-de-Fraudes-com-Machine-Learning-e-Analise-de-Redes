import streamlit as st

st.set_page_config(page_title="FraudNet AI", page_icon="🛡️", layout="wide")

st.title("🛡️ FraudNet AI")
st.subheader("Detecção de fraudes, análise de redes e integração com APIs financeiras")

st.markdown('''
O **FraudNet AI** é um produto demonstrativo de Ciência de Dados aplicado a bancos,
fintechs, marketing financeiro e serviços financeiros.

A aplicação permite analisar transações via CSV, treinar modelos supervisionados,
consultar APIs públicas como a CFPB e conectar APIs externas configuradas pelo usuário.
''')

col1, col2, col3 = st.columns(3)
col1.metric("Entrada batch", "CSV / PaySim")
col2.metric("Entrada dinâmica", "APIs")
col3.metric("Saída", "Score de risco")

st.divider()
st.markdown("### Fluxo do produto")
st.code('''
Upload CSV ou API externa
        ↓
Validação e mapeamento do layout
        ↓
Feature Engineering + Métricas de Rede
        ↓
Modelo de Inferência ou Score Heurístico
        ↓
Dashboard + Exportação
''', language="text")

st.markdown("### Páginas disponíveis")
st.markdown('''
- **Analisar CSV:** upload ou leitura local de bases transacionais.
- **Treinar Modelo:** treino supervisionado com a coluna `is_fraud`.
- **API CFPB:** consulta dinâmica à base pública de reclamações financeiras dos EUA.
- **API Externa:** conector genérico para APIs JSON configuradas pelo usuário.
- **Contexto BCB:** consulta a séries públicas do Banco Central do Brasil.
''')

st.info("Para publicar no Streamlit Community Cloud, mantenha credenciais fora do código. Tokens informados pelo usuário são usados apenas na sessão atual.")
