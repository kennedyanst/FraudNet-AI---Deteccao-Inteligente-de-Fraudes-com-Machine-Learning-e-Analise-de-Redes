REQUIRED_COLUMNS = [
    "transaction_id",
    "user_id",
    "device_id",
    "card_id",
    "ip_id",
    "amount",
    "hour",
    "country",
    "channel",
]

TARGET_COLUMN = "is_fraud"

MODEL_FEATURES_NUMERIC = [
    "amount",
    "hour",
    "amount_log",
    "is_night_transaction",
    "user_degree",
    "device_degree",
    "card_degree",
    "ip_degree",
]

MODEL_FEATURES_CATEGORICAL = ["country", "channel"]
MODEL_FEATURES = MODEL_FEATURES_NUMERIC + MODEL_FEATURES_CATEGORICAL
