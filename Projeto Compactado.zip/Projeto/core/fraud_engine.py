from __future__ import annotations

from pathlib import Path
from datetime import datetime
from typing import Optional, Tuple, Dict, Any

import joblib
import numpy as np
import pandas as pd
import polars as pl

from sklearn.compose import ColumnTransformer
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression, RidgeClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV

from core.schema import REQUIRED_COLUMNS, TARGET_COLUMN, MODEL_FEATURES, MODEL_FEATURES_NUMERIC, MODEL_FEATURES_CATEGORICAL


def list_model_files(models_dir: str | Path = "models") -> list[str]:
    path = Path(models_dir)
    path.mkdir(exist_ok=True)
    return sorted([p.name for p in path.glob("*.joblib")])


def validate_required_columns(df: pl.DataFrame, include_target: bool = False) -> list[str]:
    required = list(REQUIRED_COLUMNS)
    if include_target:
        required.append(TARGET_COLUMN)
    return [col for col in required if col not in df.columns]


def read_csv_polars(file_or_path) -> pl.DataFrame:
    return pl.read_csv(file_or_path, infer_schema_length=5000, ignore_errors=True)


def adapt_layout(df: pl.DataFrame, layout: str) -> pl.DataFrame:
    layout = (layout or "fraudnet").lower()
    if layout == "fraudnet":
        return df
    if layout == "paysim":
        required = ["step", "type", "amount", "nameOrig", "nameDest"]
        missing = [c for c in required if c not in df.columns]
        if missing:
            raise ValueError(f"Layout PaySim inválido. Colunas ausentes: {', '.join(missing)}")
        out = (
            df.with_row_index("row_id")
            .with_columns([
                pl.concat_str([pl.lit("paysim_"), pl.col("row_id").cast(pl.Utf8)]).alias("transaction_id"),
                pl.col("nameOrig").cast(pl.Utf8).alias("user_id"),
                pl.concat_str([pl.lit("dev_"), pl.col("nameOrig").cast(pl.Utf8)]).alias("device_id"),
                pl.col("nameDest").cast(pl.Utf8).alias("card_id"),
                pl.concat_str([pl.lit("ip_"), pl.col("nameDest").cast(pl.Utf8)]).alias("ip_id"),
                pl.col("amount").cast(pl.Float64, strict=False).alias("amount"),
                (pl.col("step").cast(pl.Int64, strict=False) % 24).alias("hour"),
                pl.lit("SIM").alias("country"),
                pl.col("type").cast(pl.Utf8).alias("channel"),
            ])
        )
        if "isFraud" in df.columns:
            out = out.with_columns(pl.col("isFraud").cast(pl.Int64, strict=False).alias("is_fraud"))
        select_cols = list(REQUIRED_COLUMNS)
        if "is_fraud" in out.columns:
            select_cols.append("is_fraud")
        return out.select(select_cols)
    raise ValueError(f"Layout não suportado: {layout}")


def _safe_cast_base(df: pl.DataFrame) -> pl.DataFrame:
    return df.with_columns([
        pl.col("transaction_id").cast(pl.Utf8, strict=False),
        pl.col("user_id").cast(pl.Utf8, strict=False),
        pl.col("device_id").cast(pl.Utf8, strict=False),
        pl.col("card_id").cast(pl.Utf8, strict=False),
        pl.col("ip_id").cast(pl.Utf8, strict=False),
        pl.col("country").cast(pl.Utf8, strict=False).fill_null("UNKNOWN"),
        pl.col("channel").cast(pl.Utf8, strict=False).fill_null("UNKNOWN"),
        pl.col("amount").cast(pl.Float64, strict=False).fill_null(0),
        pl.col("hour").cast(pl.Int64, strict=False).fill_null(0),
    ])


def build_features(df: pl.DataFrame) -> pl.DataFrame:
    df = _safe_cast_base(df)
    df = df.with_columns([
        pl.when(pl.col("amount") < 0).then(0).otherwise(pl.col("amount")).alias("amount"),
        pl.when(pl.col("hour") < 0).then(0).when(pl.col("hour") > 23).then(pl.col("hour") % 24).otherwise(pl.col("hour")).alias("hour"),
    ])
    df = df.with_columns([
        (pl.col("amount") + 1).log().alias("amount_log"),
        pl.when((pl.col("hour") >= 0) & (pl.col("hour") <= 5)).then(1).otherwise(0).alias("is_night_transaction"),
    ])
    user_degree = df.group_by("user_id").agg(pl.len().alias("user_degree"))
    device_degree = df.group_by("device_id").agg(pl.len().alias("device_degree"))
    card_degree = df.group_by("card_id").agg(pl.len().alias("card_degree"))
    ip_degree = df.group_by("ip_id").agg(pl.len().alias("ip_degree"))
    return df.join(user_degree, on="user_id", how="left").join(device_degree, on="device_id", how="left").join(card_degree, on="card_id", how="left").join(ip_degree, on="ip_id", how="left")


def add_risk_level(df: pl.DataFrame, threshold_medium: float = 0.45, threshold_high: float = 0.75) -> pl.DataFrame:
    return df.with_columns([
        pl.when(pl.col("fraud_score") >= threshold_high).then(pl.lit("Alto"))
        .when(pl.col("fraud_score") >= threshold_medium).then(pl.lit("Médio"))
        .otherwise(pl.lit("Baixo"))
        .alias("risk_level")
    ])


def apply_heuristic_score(df_features: pl.DataFrame) -> pl.DataFrame:
    amount_mean = max(float(df_features["amount"].mean() or 1), 1)
    max_device = max(int(df_features["device_degree"].max() or 1), 1)
    max_card = max(int(df_features["card_degree"].max() or 1), 1)
    max_ip = max(int(df_features["ip_degree"].max() or 1), 1)
    max_user = max(int(df_features["user_degree"].max() or 1), 1)
    scored = df_features.with_columns([
        (((pl.col("amount") / amount_mean).clip(0, 10) / 10) * 0.30
        + pl.col("is_night_transaction") * 0.15
        + (pl.col("device_degree") / max_device) * 0.18
        + (pl.col("ip_degree") / max_ip) * 0.18
        + (pl.col("card_degree") / max_card) * 0.12
        + (pl.col("user_degree") / max_user) * 0.07).alias("fraud_score")
    ])
    return add_risk_level(scored)


def load_model_bundle(model_path: str | Path) -> Dict[str, Any]:
    bundle = joblib.load(model_path)
    if isinstance(bundle, dict) and "pipeline" in bundle:
        return bundle
    return {"pipeline": bundle, "features": MODEL_FEATURES, "threshold_medium": 0.45, "threshold_high": 0.75, "metadata": {}}


def apply_model_score(df_features: pl.DataFrame, model_path: str | Path) -> pl.DataFrame:
    bundle = load_model_bundle(model_path)
    model = bundle["pipeline"]
    features = bundle.get("features", MODEL_FEATURES)
    pdf = df_features.select(features).to_pandas()
    if hasattr(model, "predict_proba"):
        scores = model.predict_proba(pdf)[:, 1]
    elif hasattr(model, "decision_function"):
        raw = model.decision_function(pdf)
        scores = 1 / (1 + np.exp(-raw))
    else:
        scores = np.asarray(model.predict(pdf), dtype=float)
    scored = df_features.with_columns(pl.Series("fraud_score", scores))
    return add_risk_level(scored, float(bundle.get("threshold_medium", 0.45)), float(bundle.get("threshold_high", 0.75)))


def process_transactions(df: pl.DataFrame, layout: str = "fraudnet", model_path: Optional[str | Path] = None) -> pl.DataFrame:
    df = adapt_layout(df, layout)
    missing = validate_required_columns(df)
    if missing:
        raise ValueError(f"Colunas obrigatórias ausentes: {', '.join(missing)}")
    features = build_features(df)
    result = apply_model_score(features, model_path) if model_path else apply_heuristic_score(features)
    output_cols = ["transaction_id", "user_id", "device_id", "card_id", "ip_id", "amount", "hour", "country", "channel", "user_degree", "device_degree", "card_degree", "ip_degree", "amount_log", "is_night_transaction", "fraud_score", "risk_level"]
    if TARGET_COLUMN in result.columns:
        output_cols.append(TARGET_COLUMN)
    return result.select([c for c in output_cols if c in result.columns])


def get_preprocessor() -> ColumnTransformer:
    return ColumnTransformer([
        ("num", StandardScaler(), MODEL_FEATURES_NUMERIC),
        ("cat", OneHotEncoder(handle_unknown="ignore"), MODEL_FEATURES_CATEGORICAL),
    ], remainder="drop")


def get_candidate_models(sample_size: int) -> Dict[str, Pipeline]:
    candidates = {
        "Regressão Logística": Pipeline([("prep", get_preprocessor()), ("model", LogisticRegression(max_iter=1000, class_weight="balanced"))]),
        "Regressão Logística Lasso": Pipeline([("prep", get_preprocessor()), ("model", LogisticRegression(max_iter=1000, penalty="l1", solver="liblinear", class_weight="balanced"))]),
        "Regressão Logística Ridge": Pipeline([("prep", get_preprocessor()), ("model", LogisticRegression(max_iter=1000, penalty="l2", class_weight="balanced"))]),
        "Árvore de Decisão": Pipeline([("prep", get_preprocessor()), ("model", DecisionTreeClassifier(max_depth=9, min_samples_leaf=50, class_weight="balanced", random_state=42))]),
        "Ridge Classifier": Pipeline([("prep", get_preprocessor()), ("model", RidgeClassifier(class_weight="balanced"))]),
    }
    if sample_size <= 200_000:
        candidates["SVM Linear Calibrado"] = Pipeline([("prep", get_preprocessor()), ("model", CalibratedClassifierCV(LinearSVC(class_weight="balanced", max_iter=3000, random_state=42), cv=3))])
    return candidates


def _score_model(model, X_test: pd.DataFrame) -> np.ndarray:
    if hasattr(model, "predict_proba"):
        return model.predict_proba(X_test)[:, 1]
    if hasattr(model, "decision_function"):
        raw = model.decision_function(X_test)
        return 1 / (1 + np.exp(-raw))
    return np.asarray(model.predict(X_test), dtype=float)


def train_models(df: pl.DataFrame, layout: str = "fraudnet", sample_size: int = 100_000, model_name_prefix: str = "fraudnet_model", models_dir: str | Path = "models") -> Tuple[pd.DataFrame, Path, Dict[str, Any]]:
    df = adapt_layout(df, layout)
    missing = validate_required_columns(df, include_target=True)
    if missing:
        raise ValueError(f"Para treinar, o CSV precisa conter: {', '.join(missing)}")
    if sample_size and df.height > sample_size:
        df = df.sample(n=sample_size, seed=42)
    features_df = build_features(df).with_columns([pl.col(TARGET_COLUMN).cast(pl.Int64, strict=False).fill_null(0)])
    pdf = features_df.select(MODEL_FEATURES + [TARGET_COLUMN]).to_pandas().dropna(subset=[TARGET_COLUMN])
    X = pdf[MODEL_FEATURES]
    y = pdf[TARGET_COLUMN].astype(int)
    if y.nunique() < 2:
        raise ValueError("A coluna is_fraud precisa ter pelo menos duas classes: 0 e 1.")
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
    candidates = get_candidate_models(sample_size=len(X_train))
    metrics, fitted = [], {}
    for name, model in candidates.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        score = _score_model(model, X_test)
        try:
            roc_auc = roc_auc_score(y_test, score)
        except Exception:
            roc_auc = np.nan
        metrics.append({"modelo": name, "accuracy": accuracy_score(y_test, pred), "precision": precision_score(y_test, pred, zero_division=0), "recall": recall_score(y_test, pred, zero_division=0), "f1_score": f1_score(y_test, pred, zero_division=0), "roc_auc": roc_auc})
        fitted[name] = model
    metrics_df = pd.DataFrame(metrics).sort_values(by=["f1_score", "roc_auc"], ascending=False)
    best_name = metrics_df.iloc[0]["modelo"]
    best_model = fitted[best_name]
    models_path = Path(models_dir)
    models_path.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    save_path = models_path / f"{model_name_prefix}_{timestamp}.joblib"
    bundle = {"pipeline": best_model, "features": MODEL_FEATURES, "numeric_features": MODEL_FEATURES_NUMERIC, "categorical_features": MODEL_FEATURES_CATEGORICAL, "threshold_medium": 0.45, "threshold_high": 0.75, "metadata": {"created_at": timestamp, "best_model": best_name, "rows_used": int(len(pdf)), "target": TARGET_COLUMN}, "metrics": metrics_df.to_dict(orient="records")}
    joblib.dump(bundle, save_path)
    return metrics_df, save_path, bundle
