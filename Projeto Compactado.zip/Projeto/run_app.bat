@echo off
echo ============================================
echo FraudNet AI - Streamlit App
echo ============================================
IF NOT EXIST .venv (
    echo Criando ambiente virtual...
    python -m venv .venv
)
call .venv\Scripts\activate
echo Instalando dependencias...
python -m pip install --upgrade pip
pip install -r requirements.txt
IF NOT EXIST data\exemplo_transacoes.csv (
    echo Gerando base de exemplo...
    python generate_sample_data.py
)
echo Iniciando aplicacao...
streamlit run app.py
pause
