@echo off
echo Iniciando FraudNet AI no ambiente Python atual...
streamlit run app.py
pause
