import argparse
from pathlib import Path
import numpy as np
import pandas as pd


def generate_large(rows, chunk_size, output, seed=42):
    rng = np.random.default_rng(seed)
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    countries = np.array(["BR", "US", "AR", "PT", "MX", "CO", "CL", "CA", "NG", "CN"])
    country_probs = np.array([0.72, 0.08, 0.03, 0.03, 0.03, 0.025, 0.02, 0.015, 0.015, 0.01])
    country_probs = country_probs / country_probs.sum()
    channels = np.array(["app", "web", "pos", "atm", "api"])
    channel_probs = np.array([0.46, 0.32, 0.13, 0.05, 0.04])
    output_path = Path(output)
    if output_path.exists():
        output_path.unlink()
    for start in range(0, rows, chunk_size):
        end = min(start + chunk_size, rows)
        size = end - start
        ids = np.arange(start + 1, end + 1)
        user_num = rng.integers(1, 350_001, size=size)
        device_num = rng.integers(1, 180_001, size=size)
        card_num = rng.integers(1, 420_001, size=size)
        ip_num = rng.integers(1, 120_001, size=size)
        amount = np.clip(rng.lognormal(mean=3.8, sigma=1.1, size=size).round(2), 1, 25000)
        hour = rng.integers(0, 24, size=size)
        country = rng.choice(countries, size=size, p=country_probs)
        channel = rng.choice(channels, size=size, p=channel_probs)
        risk = ((amount > 1200).astype(float) * 0.25 + ((hour <= 5) | (hour >= 23)).astype(float) * 0.18 + np.isin(country, ["NG", "CN"]).astype(float) * 0.22 + np.isin(channel, ["api", "atm"]).astype(float) * 0.12 + (device_num % 997 == 0).astype(float) * 0.18 + (ip_num % 431 == 0).astype(float) * 0.15 + rng.normal(0, 0.06, size=size))
        prob = 1 / (1 + np.exp(-6 * (risk - 0.45)))
        is_fraud = (rng.random(size) < prob).astype(int)
        df = pd.DataFrame({
            "transaction_id": [f"txn_{i:010d}" for i in ids],
            "user_id": [f"u{i:06d}" for i in user_num],
            "device_id": [f"d{i:06d}" for i in device_num],
            "card_id": [f"c{i:06d}" for i in card_num],
            "ip_id": [f"ip{i:06d}" for i in ip_num],
            "amount": amount,
            "hour": hour,
            "country": country,
            "channel": channel,
            "is_fraud": is_fraud,
        })
        df.to_csv(output, mode="a", index=False, header=(start == 0), encoding="utf-8")
        print(f"Geradas {end:,}/{rows:,} linhas")
    print(f"Arquivo final: {output}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--rows", type=int, default=1_000_000)
    parser.add_argument("--chunk-size", type=int, default=100_000)
    parser.add_argument("--output", type=str, default="data/transacoes_1M.csv")
    args = parser.parse_args()
    generate_large(args.rows, args.chunk_size, args.output)
