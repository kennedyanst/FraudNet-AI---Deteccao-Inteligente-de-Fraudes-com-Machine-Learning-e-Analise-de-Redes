from datetime import date, timedelta

import pandas as pd
import streamlit as st

from connectors.cfpb_client import consultar_cfpb, resumir_reclamacoes
from utils.ui_helpers import dataframe_to_csv_download


st.set_page_config(page_title="FraudNet AI | API CFPB", page_icon="🌐", layout="wide")

st.title("🌐 API CFPB — Reclamações Financeiras")
st.caption("Consulta dinâmica à Consumer Complaint Database para análise de risco reputacional")
st.info(
    "A API CFPB é pública e não exige token. Ela é usada como fonte real de reclamações "
    "financeiras, não como API de transações bancárias."
)


@st.cache_data(ttl=900, show_spinner=False)
def consultar_cfpb_cacheado(produto, empresa, estado, data_inicial, data_final, termo, limite):
    return consultar_cfpb(
        produto=produto,
        empresa=empresa,
        estado=estado,
        data_inicial=data_inicial,
        data_final=data_final,
        termo=termo,
        limite=limite,
    )


def render_dashboard(df: pd.DataFrame):
    if df.empty:
        st.warning(
            "Nenhum registro encontrado para os filtros informados. "
            "Tente limpar o campo Empresa, ampliar o período ou reduzir filtros."
        )
        return

    resumo = resumir_reclamacoes(df)

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Reclamações", f"{resumo['registros']:,}")
    col2.metric("Empresas", f"{resumo['empresas']:,}")
    col3.metric("Produtos", f"{resumo['produtos']:,}")
    col4.metric("Estados", f"{resumo['estados']:,}")

    st.divider()

    tab1, tab2, tab3, tab4 = st.tabs(["Dados", "Empresas", "Problemas", "Série temporal"])

    with tab1:
        st.subheader("Prévia dos registros")
        st.dataframe(df.head(1000), use_container_width=True)
        dataframe_to_csv_download(df, "cfpb_reclamacoes.csv")

    with tab2:
        if "company" in df.columns:
            ranking = df["company"].value_counts().head(20).reset_index()
            ranking.columns = ["company", "quantidade"]
            st.bar_chart(ranking, x="company", y="quantidade")
            st.dataframe(ranking, use_container_width=True)
        else:
            st.warning("A resposta da API não trouxe a coluna company.")

    with tab3:
        if "issue" in df.columns:
            ranking = df["issue"].value_counts().head(20).reset_index()
            ranking.columns = ["issue", "quantidade"]
            st.bar_chart(ranking, x="issue", y="quantidade")
            st.dataframe(ranking, use_container_width=True)
        else:
            st.warning("A resposta da API não trouxe a coluna issue.")

    with tab4:
        if "date_received" in df.columns:
            temp = df.copy()
            temp["date_received"] = pd.to_datetime(temp["date_received"], errors="coerce")
            serie = (
                temp.dropna(subset=["date_received"])
                .assign(data=lambda x: x["date_received"].dt.date)
                .groupby("data", as_index=False)
                .size()
                .rename(columns={"size": "quantidade"})
            )

            if not serie.empty:
                st.line_chart(serie, x="data", y="quantidade")
                st.dataframe(serie, use_container_width=True)
            else:
                st.warning("Não foi possível montar a série temporal com a coluna date_received.")
        else:
            st.warning("A resposta da API não trouxe a coluna date_received.")


with st.sidebar:
    st.header("Filtros da API")

    produto = st.selectbox(
        "Produto financeiro",
        [
            "",
            "Credit card",
            "Checking or savings account",
            "Mortgage",
            "Debt collection",
            "Credit reporting or other personal consumer reports",
            "Money transfer, virtual currency, or money service",
            "Personal loan",
            "Student loan",
            "Vehicle loan or lease",
        ],
    )

    empresa = st.text_input(
        "Empresa",
        placeholder="Ex: BANK OF AMERICA",
        help="Opcional. Se a consulta retornar vazia, tente deixar este campo em branco.",
    )

    estado = st.text_input("Estado", placeholder="Ex: NY, CA, FL")
    termo = st.text_input("Palavra-chave", placeholder="Ex: fraud, card, account")

    hoje = date.today()
    data_inicial = st.text_input("Data inicial", value=(hoje - timedelta(days=365)).strftime("%Y-%m-%d"))
    data_final = st.text_input("Data final", value=hoje.strftime("%Y-%m-%d"))

    limite = st.slider("Limite de registros", 100, 5000, 500, step=100)

    auto_refresh = st.checkbox("Atualização dinâmica", value=False)
    intervalo = st.slider("Intervalo em segundos", 30, 300, 60, step=30)

    consultar = st.button("Consultar API", type="primary")


def executar_consulta():
    try:
        with st.spinner("Consultando API CFPB..."):
            df = consultar_cfpb_cacheado(
                produto or None,
                empresa or None,
                estado or None,
                data_inicial or None,
                data_final or None,
                termo or None,
                limite,
            )

        render_dashboard(df)

    except Exception as exc:
        st.error("Não foi possível consultar ou interpretar a resposta da API CFPB.")
        st.exception(exc)
        st.info(
            "Teste rápido: deixe apenas Produto financeiro preenchido e limpe Empresa, Estado "
            "e Palavra-chave. Depois clique em Consultar API novamente."
        )


if auto_refresh and hasattr(st, "fragment"):
    st.caption(f"Atualização dinâmica ativa. Consulta refeita a cada {intervalo} segundos.")

    @st.fragment(run_every=f"{intervalo}s")
    def painel_dinamico():
        executar_consulta()

    painel_dinamico()

elif consultar:
    executar_consulta()

else:
    st.markdown(
        "Configure os filtros na barra lateral e clique em **Consultar API**. "
        "Para simular monitoramento quase em tempo real, ative **Atualização dinâmica**."
    )
