import pandas as pd
import polars as pl
import streamlit as st
from connectors.generic_api_client import ApiSecurityError, build_headers, consultar_api_generica, map_to_fraudnet_layout, parse_json_text
from core.fraud_engine import process_transactions, list_model_files
from core.schema import REQUIRED_COLUMNS
from utils.ui_helpers import dataframe_to_csv_download, explain_token_policy

st.set_page_config(page_title="FraudNet AI | API Externa", page_icon="🔌", layout="wide")
st.title("🔌 Conectar API Externa")
st.caption("Conector configurável para APIs JSON informadas pelo usuário")
st.info("Teste uma API externa, extraia dados JSON, mapeie colunas para o layout FraudNet e execute a análise de risco.")
explain_token_policy()

with st.sidebar:
    st.header("Configuração da API")
    url = st.text_input("URL da API", placeholder="https://api.exemplo.com/transacoes")
    method = st.selectbox("Método", ["GET", "POST"])
    data_path = st.text_input("Caminho dos dados no JSON", placeholder="data.transactions ou hits.hits")
    params_json = st.text_area("Parâmetros JSON", value="{}", help='Exemplo: {"limit": 100, "status": "pending"}')
    body_json = st.text_area("Body JSON para POST", value="{}", help="Usado somente no método POST.")
    auth_type = st.selectbox("Autenticação", ["Nenhum", "Bearer Token", "API Key Header"])
    token = st.text_input("Token/API Key", type="password")
    custom_headers_json = st.text_area("Headers adicionais JSON", value="{}", help='Exemplo: {"Accept": "application/json"}')
    st.divider()
    modelos = list_model_files("models")
    model_choice = st.selectbox("Modelo de inferência", ["Score heurístico"] + modelos)
    model_path = None if model_choice == "Score heurístico" else f"models/{model_choice}"
    auto_refresh = st.checkbox("Atualização dinâmica", value=False)
    intervalo = st.slider("Intervalo em segundos", 30, 300, 60, step=30)
    testar = st.button("Testar conexão", type="primary")


def fetch_api_data():
    if not url:
        st.warning("Informe a URL da API.")
        return None
    try:
        params = parse_json_text(params_json, default={})
        body = parse_json_text(body_json, default={})
        headers = build_headers(auth_type, token, custom_headers_json)
        with st.spinner("Consultando API externa..."):
            return consultar_api_generica(url=url, method=method, headers=headers, params=params, body=body, data_path=data_path or None)
    except ApiSecurityError as exc:
        st.error(str(exc))
    except Exception as exc:
        st.error(f"Erro ao consultar API: {exc}")
    return None


def render_mapping_and_analysis(df: pd.DataFrame):
    if df is None or df.empty:
        st.warning("A API não retornou registros.")
        return
    st.success(f"API consultada com sucesso: {len(df):,} registros e {len(df.columns):,} colunas.")
    st.subheader("Prévia da resposta")
    st.dataframe(df.head(200), use_container_width=True)
    st.subheader("Mapeamento para layout FraudNet")
    st.markdown("Selecione quais colunas da API correspondem ao layout interno do FraudNet. Quando uma coluna não existir, deixe como **Gerar automaticamente**.")
    options = ["Gerar automaticamente"] + list(df.columns)
    mapping = {}
    cols = st.columns(3)
    for idx, target in enumerate(REQUIRED_COLUMNS + ["is_fraud"]):
        with cols[idx % 3]:
            selected = st.selectbox(target, options, key=f"map_{target}")
            if selected != "Gerar automaticamente":
                mapping[target] = selected
    if st.button("Converter e analisar dados da API", type="primary"):
        mapped = map_to_fraudnet_layout(df, mapping)
        st.subheader("Dados convertidos para FraudNet")
        st.dataframe(mapped.head(200), use_container_width=True)
        with st.spinner("Executando análise FraudNet AI..."):
            result = process_transactions(pl.from_pandas(mapped), layout="fraudnet", model_path=model_path)
        total = result.height
        alto = result.filter(pl.col("risk_level") == "Alto").height
        medio = result.filter(pl.col("risk_level") == "Médio").height
        baixo = result.filter(pl.col("risk_level") == "Baixo").height
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Registros", f"{total:,}")
        col2.metric("Alto risco", f"{alto:,}", f"{alto/total:.1%}" if total else "0%")
        col3.metric("Médio risco", f"{medio:,}", f"{medio/total:.1%}" if total else "0%")
        col4.metric("Baixo risco", f"{baixo:,}", f"{baixo/total:.1%}" if total else "0%")
        resumo = result.group_by("risk_level").agg(pl.len().alias("quantidade")).to_pandas()
        st.bar_chart(resumo, x="risk_level", y="quantidade")
        st.subheader("Resultado")
        st.dataframe(result.head(5000).to_pandas(), use_container_width=True)
        dataframe_to_csv_download(result, "fraudnet_api_externa_resultado.csv")

if auto_refresh and hasattr(st, "fragment"):
    st.caption(f"Atualização dinâmica ativa a cada {intervalo} segundos.")
    @st.fragment(run_every=f"{intervalo}s")
    def live_api_panel():
        df_api = fetch_api_data()
        render_mapping_and_analysis(df_api)
    live_api_panel()
elif testar:
    df_api = fetch_api_data()
    if df_api is not None:
        st.session_state["api_externa_df"] = df_api

if "api_externa_df" in st.session_state:
    render_mapping_and_analysis(st.session_state["api_externa_df"])
else:
    st.markdown("Configure a API na barra lateral e clique em **Testar conexão**. URLs internas/privadas são bloqueadas por segurança.")
