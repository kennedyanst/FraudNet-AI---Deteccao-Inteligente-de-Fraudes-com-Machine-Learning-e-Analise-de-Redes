from pathlib import Path
import polars as pl
import streamlit as st
from core.fraud_engine import list_model_files, process_transactions, read_csv_polars, validate_required_columns, adapt_layout
from core.schema import REQUIRED_COLUMNS
from utils.ui_helpers import show_dataframe_preview, dataframe_to_csv_download

st.set_page_config(page_title="FraudNet AI | Analisar CSV", page_icon="🛡️", layout="wide")
st.title("🛡️ Analisar CSV")
st.caption("Análise batch de transações via upload ou caminho local")

with st.sidebar:
    st.header("Configurações")
    layout = st.selectbox("Layout da base", ["fraudnet", "paysim"], format_func=lambda x: "FraudNet AI" if x == "fraudnet" else "PaySim")
    modelos = list_model_files("models")
    model_choice = st.selectbox("Modelo de inferência", ["Score heurístico"] + modelos)
    model_path = None if model_choice == "Score heurístico" else str(Path("models") / model_choice)
    input_mode = st.radio("Modo de entrada", ["Upload CSV", "Caminho local"], help="No Streamlit Cloud, caminho local é o servidor da aplicação, não o computador do usuário.")
    st.divider()
    st.markdown("**Colunas esperadas no layout FraudNet:**")
    st.code("\n".join(REQUIRED_COLUMNS), language="text")

df = None
if input_mode == "Upload CSV":
    uploaded = st.file_uploader("Envie o arquivo CSV", type=["csv"])
    if uploaded is not None:
        with st.spinner("Lendo CSV..."):
            df = read_csv_polars(uploaded)
else:
    local_path = st.text_input("Caminho local do CSV", placeholder=r"C:\Projetos\fraudnet\data\transacoes.csv")
    if local_path and st.button("Ler arquivo local"):
        with st.spinner("Lendo CSV local..."):
            df = read_csv_polars(local_path)

if df is not None:
    st.success(f"Arquivo carregado: {df.height:,} linhas e {df.width:,} colunas.")
    st.subheader("Prévia da base original")
    show_dataframe_preview(df, n=50)
    try:
        df_padrao = adapt_layout(df, layout)
    except Exception as exc:
        st.error(f"Erro ao adaptar layout: {exc}")
        st.stop()
    missing = validate_required_columns(df_padrao)
    if missing:
        st.error(f"Colunas obrigatórias ausentes após adaptação: {', '.join(missing)}")
        st.stop()
    st.subheader("Prévia no layout FraudNet")
    show_dataframe_preview(df_padrao, n=50)
    if st.button("Executar análise FraudNet AI", type="primary"):
        with st.spinner("Calculando features de rede, score e classificação de risco..."):
            resultado = process_transactions(df, layout=layout, model_path=model_path)
        st.success("Análise concluída.")
        total = resultado.height
        alto = resultado.filter(pl.col("risk_level") == "Alto").height
        medio = resultado.filter(pl.col("risk_level") == "Médio").height
        baixo = resultado.filter(pl.col("risk_level") == "Baixo").height
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Transações", f"{total:,}")
        col2.metric("Alto risco", f"{alto:,}", f"{alto/total:.1%}" if total else "0%")
        col3.metric("Médio risco", f"{medio:,}", f"{medio/total:.1%}" if total else "0%")
        col4.metric("Baixo risco", f"{baixo:,}", f"{baixo/total:.1%}" if total else "0%")
        st.divider()
        resumo_risco = resultado.group_by("risk_level").agg(pl.len().alias("quantidade")).sort("quantidade", descending=True).to_pandas()
        st.subheader("Distribuição de risco")
        st.bar_chart(resumo_risco, x="risk_level", y="quantidade")
        st.subheader("Top transações por score")
        top = resultado.sort("fraud_score", descending=True).head(1000)
        st.dataframe(top.to_pandas(), use_container_width=True)
        st.subheader("Resultado completo")
        st.dataframe(resultado.head(5000).to_pandas(), use_container_width=True)
        dataframe_to_csv_download(resultado, "fraudnet_resultado.csv")
