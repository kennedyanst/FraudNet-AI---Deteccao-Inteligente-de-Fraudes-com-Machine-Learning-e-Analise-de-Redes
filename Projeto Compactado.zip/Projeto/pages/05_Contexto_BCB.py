import streamlit as st
from connectors.bcb_client import consultar_serie_sgs
from utils.ui_helpers import dataframe_to_csv_download

st.set_page_config(page_title="FraudNet AI | Contexto BCB", page_icon="🇧🇷", layout="wide")
st.title("🇧🇷 Contexto Banco Central do Brasil")
st.caption("Consulta a séries públicas do SGS para contextualização financeira")
st.info("Os dados do Banco Central não substituem a base transacional do FraudNet. Eles servem como contexto macroeconômico e financeiro.")

series_sugeridas = {"Selic Meta": 432, "IPCA": 433, "Dólar PTAX Venda": 1, "Saldo da carteira de crédito com recursos livres - total": 20542}

with st.sidebar:
    st.header("Consulta SGS")
    serie_nome = st.selectbox("Série sugerida", list(series_sugeridas.keys()))
    codigo = st.number_input("Código SGS", min_value=1, value=int(series_sugeridas[serie_nome]), step=1)
    modo = st.radio("Modo", ["Últimos N valores", "Período"])
    if modo == "Últimos N valores":
        ultimos = st.slider("Últimos valores", 10, 1000, 120)
        data_inicial = None
        data_final = None
    else:
        ultimos = None
        data_inicial = st.text_input("Data inicial", value="01/01/2020")
        data_final = st.text_input("Data final", value="31/12/2026")
    consultar = st.button("Consultar BCB", type="primary")

if consultar:
    try:
        with st.spinner("Consultando API do Banco Central..."):
            df = consultar_serie_sgs(codigo=int(codigo), data_inicial=data_inicial, data_final=data_final, ultimos=ultimos)
        if df.empty:
            st.warning("Nenhum dado retornado.")
            st.stop()
        col1, col2, col3 = st.columns(3)
        col1.metric("Registros", f"{len(df):,}")
        col2.metric("Valor mais recente", f"{df['valor'].iloc[-1]:,.4f}")
        col3.metric("Data mais recente", str(df["data"].iloc[-1].date()) if "data" in df.columns else "-")
        st.subheader("Série temporal")
        st.line_chart(df, x="data", y="valor")
        st.subheader("Dados")
        st.dataframe(df, use_container_width=True)
        dataframe_to_csv_download(df, "bcb_serie_sgs.csv")
    except Exception as exc:
        st.error(f"Erro ao consultar Banco Central: {exc}")
else:
    st.markdown("Selecione uma série e clique em **Consultar BCB**.")
