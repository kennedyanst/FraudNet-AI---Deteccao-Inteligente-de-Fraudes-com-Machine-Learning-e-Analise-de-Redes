import streamlit as st
from core.fraud_engine import read_csv_polars, train_models, adapt_layout, validate_required_columns
from core.schema import TARGET_COLUMN

st.set_page_config(page_title="FraudNet AI | Treinar Modelo", page_icon="🧠", layout="wide")
st.title("🧠 Treinar Modelo")
st.caption("Treinamento supervisionado usando base rotulada com is_fraud")

with st.sidebar:
    st.header("Configurações de treino")
    layout = st.selectbox("Layout da base", ["fraudnet", "paysim"], format_func=lambda x: "FraudNet AI" if x == "fraudnet" else "PaySim")
    sample_size = st.number_input("Limite de amostra para treino local", min_value=1000, max_value=2_000_000, value=100_000, step=10_000)
    model_prefix = st.text_input("Prefixo do modelo", value="fraudnet_model")
    input_mode = st.radio("Modo de entrada", ["Upload CSV", "Caminho local"])

df = None
if input_mode == "Upload CSV":
    uploaded = st.file_uploader("Envie o CSV com a coluna is_fraud", type=["csv"])
    if uploaded is not None:
        with st.spinner("Lendo CSV..."):
            df = read_csv_polars(uploaded)
else:
    local_path = st.text_input("Caminho local do CSV", placeholder=r"C:\Projetos\fraudnet\data\transacoes_rotuladas.csv")
    if local_path and st.button("Ler arquivo local"):
        with st.spinner("Lendo CSV local..."):
            df = read_csv_polars(local_path)

if df is not None:
    st.success(f"Base carregada: {df.height:,} linhas e {df.width:,} colunas.")
    try:
        df_padrao = adapt_layout(df, layout)
    except Exception as exc:
        st.error(f"Erro ao adaptar layout: {exc}")
        st.stop()
    missing = validate_required_columns(df_padrao, include_target=True)
    if missing:
        st.error(f"Colunas ausentes para treino: {', '.join(missing)}")
        st.stop()
    st.subheader("Distribuição da variável alvo")
    dist = df_padrao.group_by(TARGET_COLUMN).len().sort(TARGET_COLUMN).to_pandas()
    st.dataframe(dist, use_container_width=True)
    if st.button("Treinar modelos", type="primary"):
        with st.spinner("Treinando modelos candidatos..."):
            metrics_df, model_path, bundle = train_models(df, layout=layout, sample_size=int(sample_size), model_name_prefix=model_prefix, models_dir="models")
        st.success(f"Modelo salvo em: {model_path}")
        st.subheader("Comparação de modelos")
        st.dataframe(metrics_df, use_container_width=True)
        best = bundle["metadata"]["best_model"]
        st.info(f"Melhor modelo selecionado pelo F1-score: **{best}**")
        st.markdown("Agora vá até **Analisar CSV** e selecione esse `.joblib` no campo **Modelo de inferência**.")
