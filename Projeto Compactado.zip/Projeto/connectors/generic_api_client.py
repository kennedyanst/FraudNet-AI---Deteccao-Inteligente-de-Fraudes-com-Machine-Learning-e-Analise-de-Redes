from __future__ import annotations
import ipaddress
import json
import socket
from typing import Any, Dict, Optional
from urllib.parse import urlparse
import pandas as pd
import requests

class ApiSecurityError(ValueError):
    pass


def is_public_http_url(url: str) -> bool:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return False
    hostname = parsed.hostname.lower()
    if hostname in {"localhost", "127.0.0.1", "0.0.0.0"}:
        return False
    try:
        ip = ipaddress.ip_address(hostname)
        return not (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast)
    except ValueError:
        pass
    try:
        for info in socket.getaddrinfo(hostname, None):
            ip = ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast:
                return False
    except Exception:
        return True
    return True


def parse_json_text(text: str, default: Any) -> Any:
    if not text or not text.strip():
        return default
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"JSON inválido: {exc}") from exc


def extract_by_path(payload: Any, data_path: Optional[str]) -> Any:
    if not data_path:
        return payload
    current = payload
    for part in data_path.split("."):
        if isinstance(current, dict):
            current = current.get(part, [])
        elif isinstance(current, list):
            try:
                current = current[int(part)]
            except Exception:
                return []
        else:
            return []
    return current


def normalize_records(records: Any) -> pd.DataFrame:
    if isinstance(records, dict):
        records = [records]
    if not isinstance(records, list):
        records = []
    return pd.json_normalize(records)


def consultar_api_generica(url: str, method: str = "GET", headers: Optional[Dict[str, str]] = None, params: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, data_path: Optional[str] = None, timeout: int = 40) -> pd.DataFrame:
    if not is_public_http_url(url):
        raise ApiSecurityError("URL bloqueada por segurança. Use apenas endpoints públicos HTTP/HTTPS.")
    headers = headers or {}
    params = params or {}
    method = method.upper().strip()
    if method == "GET":
        response = requests.get(url, headers=headers, params=params, timeout=timeout)
    elif method == "POST":
        response = requests.post(url, headers=headers, params=params, json=body or {}, timeout=timeout)
    else:
        raise ValueError("Método não suportado. Use GET ou POST.")
    response.raise_for_status()
    payload = response.json()
    return normalize_records(extract_by_path(payload, data_path))


def build_headers(auth_type: str = "Nenhum", token: str = "", custom_headers_json: str = "") -> Dict[str, str]:
    headers = parse_json_text(custom_headers_json, default={})
    if token:
        if auth_type == "Bearer Token":
            headers["Authorization"] = f"Bearer {token}"
        elif auth_type == "API Key Header":
            headers.setdefault("x-api-key", token)
    return headers


def map_to_fraudnet_layout(df: pd.DataFrame, mapping: Dict[str, str]) -> pd.DataFrame:
    out = pd.DataFrame()
    n = len(df)
    def col_or_default(target: str, default):
        source = mapping.get(target)
        if source and source in df.columns:
            return df[source]
        return default
    out["transaction_id"] = col_or_default("transaction_id", pd.Series([f"api_txn_{i+1:010d}" for i in range(n)])).astype(str)
    out["user_id"] = col_or_default("user_id", pd.Series([f"api_user_{i % 10000:06d}" for i in range(n)])).astype(str)
    out["device_id"] = col_or_default("device_id", pd.Series([f"api_device_{i % 5000:06d}" for i in range(n)])).astype(str)
    out["card_id"] = col_or_default("card_id", pd.Series([f"api_card_{i % 12000:06d}" for i in range(n)])).astype(str)
    out["ip_id"] = col_or_default("ip_id", pd.Series([f"api_ip_{i % 2500:06d}" for i in range(n)])).astype(str)
    out["amount"] = pd.to_numeric(col_or_default("amount", pd.Series([0] * n)), errors="coerce").fillna(0)
    out["hour"] = pd.to_numeric(col_or_default("hour", pd.Series([12] * n)), errors="coerce").fillna(12).astype(int) % 24
    out["country"] = col_or_default("country", pd.Series(["API"] * n)).astype(str)
    out["channel"] = col_or_default("channel", pd.Series(["api"] * n)).astype(str)
    if "is_fraud" in mapping and mapping["is_fraud"] in df.columns:
        out["is_fraud"] = pd.to_numeric(df[mapping["is_fraud"]], errors="coerce").fillna(0).astype(int)
    return out
