from __future__ import annotations
from typing import Optional
import pandas as pd
import requests

BCB_SGS_URL = "https://api.bcb.gov.br/dados/serie/bcdata.sgs.{codigo}/dados"


def consultar_serie_sgs(codigo: int, data_inicial: Optional[str] = None, data_final: Optional[str] = None, ultimos: Optional[int] = None) -> pd.DataFrame:
    if ultimos:
        url = f"https://api.bcb.gov.br/dados/serie/bcdata.sgs.{codigo}/dados/ultimos/{int(ultimos)}"
        params = {"formato": "json"}
    else:
        url = BCB_SGS_URL.format(codigo=int(codigo))
        params = {"formato": "json"}
        if data_inicial:
            params["dataInicial"] = data_inicial
        if data_final:
            params["dataFinal"] = data_final
    response = requests.get(url, params=params, timeout=40)
    response.raise_for_status()
    df = pd.DataFrame(response.json())
    if df.empty:
        return df
    if "data" in df.columns:
        df["data"] = pd.to_datetime(df["data"], dayfirst=True, errors="coerce")
    if "valor" in df.columns:
        df["valor"] = pd.to_numeric(df["valor"], errors="coerce")
    return df
