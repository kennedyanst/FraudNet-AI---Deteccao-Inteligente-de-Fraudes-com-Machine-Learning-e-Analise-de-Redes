from __future__ import annotations

from typing import Any, Optional

import pandas as pd
import requests

CFPB_API_URL = "https://www.consumerfinance.gov/data-research/consumer-complaints/search/api/v1/"


def _extrair_registros_cfpb(payload: Any) -> list[dict]:
    """
    Trata formatos diferentes de resposta da API CFPB.

    Formatos suportados:
    1) {"hits": {"hits": [{"_source": {...}}, ...]}}
    2) [{...}, {...}]
    3) {"data": [...]}, {"results": [...]}, {"complaints": [...]}, {"items": [...]}
    """
    registros: list[dict] = []

    if isinstance(payload, list):
        candidatos = payload

    elif isinstance(payload, dict):
        hits = payload.get("hits")

        if isinstance(hits, dict):
            candidatos = hits.get("hits", [])
        elif isinstance(hits, list):
            candidatos = hits
        else:
            candidatos = None

        if candidatos is None:
            for chave in ("data", "results", "complaints", "items"):
                valor = payload.get(chave)
                if isinstance(valor, list):
                    candidatos = valor
                    break

        if candidatos is None:
            candidatos = [payload]

    else:
        candidatos = []

    for item in candidatos:
        if not isinstance(item, dict):
            continue

        fonte = item.get("_source")
        if isinstance(fonte, dict):
            registros.append(fonte)
        else:
            registros.append(item)

    return registros


def consultar_cfpb(
    produto: Optional[str] = None,
    empresa: Optional[str] = None,
    estado: Optional[str] = None,
    data_inicial: Optional[str] = None,
    data_final: Optional[str] = None,
    termo: Optional[str] = None,
    limite: int = 500,
) -> pd.DataFrame:
    params = {
        "size": int(limite),
        "format": "json",
        "sort": "created_date_desc",
    }

    if produto:
        params["product"] = produto
    if empresa:
        params["company"] = empresa
    if estado:
        params["state"] = estado
    if data_inicial:
        params["date_received_min"] = data_inicial
    if data_final:
        params["date_received_max"] = data_final
    if termo:
        params["search_term"] = termo
        params["field"] = "all"

    try:
        response = requests.get(CFPB_API_URL, params=params, timeout=40)
        response.raise_for_status()
    except requests.exceptions.RequestException as exc:
        raise RuntimeError(
            "Falha ao consultar a API CFPB. Verifique sua internet, os filtros informados "
            f"ou tente novamente com uma consulta mais ampla. Detalhe técnico: {exc}"
        ) from exc

    try:
        payload = response.json()
    except ValueError as exc:
        raise RuntimeError("A API CFPB não retornou um JSON válido para esta consulta.") from exc

    registros = _extrair_registros_cfpb(payload)
    df = pd.DataFrame(registros)

    if df.empty:
        return df

    rename_map = {
        "date_received": "date_received",
        "Date received": "date_received",
        "product": "product",
        "Product": "product",
        "sub_product": "sub_product",
        "Sub-product": "sub_product",
        "issue": "issue",
        "Issue": "issue",
        "sub_issue": "sub_issue",
        "Sub-issue": "sub_issue",
        "company": "company",
        "Company": "company",
        "state": "state",
        "State": "state",
        "zip_code": "zip_code",
        "ZIP code": "zip_code",
        "consumer_complaint_narrative": "consumer_complaint_narrative",
        "Consumer complaint narrative": "consumer_complaint_narrative",
        "company_response": "company_response",
        "Company response to consumer": "company_response",
        "timely": "timely",
        "Timely response?": "timely",
        "submitted_via": "submitted_via",
        "Submitted via": "submitted_via",
    }

    df = df.rename(columns={k: v for k, v in rename_map.items() if k in df.columns})
    df = df.dropna(axis=1, how="all")

    return df


def resumir_reclamacoes(df: pd.DataFrame) -> dict:
    if df.empty:
        return {"registros": 0, "empresas": 0, "produtos": 0, "estados": 0}

    return {
        "registros": int(len(df)),
        "empresas": int(df["company"].nunique()) if "company" in df.columns else 0,
        "produtos": int(df["product"].nunique()) if "product" in df.columns else 0,
        "estados": int(df["state"].nunique()) if "state" in df.columns else 0,
    }
