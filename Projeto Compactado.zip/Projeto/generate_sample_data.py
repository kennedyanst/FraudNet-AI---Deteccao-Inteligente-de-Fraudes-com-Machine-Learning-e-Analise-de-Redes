import numpy as np
import pandas as pd
from pathlib import Path


def generate_sample(n_rows=5000, output="data/exemplo_transacoes.csv", seed=42):
    rng = np.random.default_rng(seed)
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    countries = np.array(["BR", "US", "AR", "PT", "MX", "CO", "CL", "CA", "NG", "CN"])
    channels = np.array(["app", "web", "pos", "atm", "api"])
    ids = np.arange(1, n_rows + 1)
    user_num = rng.integers(1, 5000, size=n_rows)
    device_num = rng.integers(1, 2500, size=n_rows)
    card_num = rng.integers(1, 6000, size=n_rows)
    ip_num = rng.integers(1, 1500, size=n_rows)
    amount = np.clip(rng.lognormal(mean=3.8, sigma=1.1, size=n_rows).round(2), 1, 25000)
    hour = rng.integers(0, 24, size=n_rows)
    country = rng.choice(countries, size=n_rows)
    channel = rng.choice(channels, size=n_rows)
    risk = ((amount > 1200).astype(float) * 0.25 + ((hour <= 5) | (hour >= 23)).astype(float) * 0.18 + np.isin(country, ["NG", "CN"]).astype(float) * 0.22 + np.isin(channel, ["api", "atm"]).astype(float) * 0.12 + rng.normal(0, 0.06, size=n_rows))
    prob = 1 / (1 + np.exp(-6 * (risk - 0.45)))
    is_fraud = (rng.random(n_rows) < prob).astype(int)
    df = pd.DataFrame({
        "transaction_id": [f"txn_{i:010d}" for i in ids],
        "user_id": [f"u{i:06d}" for i in user_num],
        "device_id": [f"d{i:06d}" for i in device_num],
        "card_id": [f"c{i:06d}" for i in card_num],
        "ip_id": [f"ip{i:06d}" for i in ip_num],
        "amount": amount,
        "hour": hour,
        "country": country,
        "channel": channel,
        "is_fraud": is_fraud,
    })
    df.to_csv(output, index=False, encoding="utf-8")
    print(f"Arquivo gerado: {output}")
    print(f"Linhas: {len(df):,}")

if __name__ == "__main__":
    generate_sample()
