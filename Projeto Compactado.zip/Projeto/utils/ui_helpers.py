from __future__ import annotations
import pandas as pd
import streamlit as st


def show_dataframe_preview(df, n: int = 100):
    if hasattr(df, "to_pandas"):
        st.dataframe(df.head(n).to_pandas(), use_container_width=True)
    else:
        st.dataframe(df.head(n), use_container_width=True)


def dataframe_to_csv_download(df, file_name: str):
    if hasattr(df, "write_csv"):
        data = df.write_csv().encode("utf-8")
    elif isinstance(df, pd.DataFrame):
        data = df.to_csv(index=False).encode("utf-8")
    else:
        data = str(df).encode("utf-8")
    st.download_button("Baixar CSV", data=data, file_name=file_name, mime="text/csv")


def explain_token_policy():
    st.warning("Para APIs privadas, informe tokens apenas se confiar no endpoint. O FraudNet usa o token somente na sessão atual e não grava em arquivo.")
