# Guia de API Pública no FraudNet AI

## Objetivo

Permitir que usuários conectem o FraudNet AI a APIs externas sem editar código.

## Tipos de API suportados

### 1. CFPB

API pública de reclamações financeiras. Não exige token.

Uso ideal:

- risco reputacional;
- NLP;
- análise de reclamações;
- ranking de empresas e problemas.

### 2. API Genérica JSON

Permite conectar qualquer endpoint público que retorne JSON.

O usuário configura:

- URL;
- método;
- parâmetros;
- headers;
- token;
- caminho dos dados;
- mapeamento das colunas.

## Exemplo de data_path

Se a API retorna:

```json
{
  "data": {
    "transactions": [
      {"id": 1, "amount": 100}
    ]
  }
}
```

Use:

```text
data.transactions
```

## Mapeamento

A API precisa ser mapeada para:

```text
transaction_id
user_id
device_id
card_id
ip_id
amount
hour
country
channel
```

Campos ausentes podem ser gerados automaticamente para fins de demonstração.

## Atualização dinâmica

Quando disponível, o app usa `st.fragment(run_every="60s")` para consultar a API em intervalos periódicos.
